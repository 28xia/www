<div class="col-12 _404">
	<div class="_404-inner">
		<h1 class="entry-title">暂无内容</h1>
		<div class="entry-content">抱歉，没有找到您需要的文章，可以搜索看看</div>
		<?php get_search_form(); ?>
	</div>
</div>